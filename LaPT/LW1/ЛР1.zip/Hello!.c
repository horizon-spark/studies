/* Hello!.c
--------------------------
(с)оздал: Кадарметов Д.Н.
группа  : БИВТ-ВП-23
дата    : 09.03.2024
---------------------------------------
Вывод в консоль фразы "Hello, my name is Dmitry"
*/

#include <stdio.h>

void main() 
{
    printf("Hello, my name is Dmitry");
}
